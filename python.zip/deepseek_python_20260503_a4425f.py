import tkinter as tk
from tkinter import messagebox, ttk
import random
import json
import os
from datetime import datetime

# ------------------- РАБОТА С ДАННЫМИ -------------------
QUOTES_FILE = "quotes.json"
HISTORY_FILE = "history.json"

# Предопределённые цитаты
DEFAULT_QUOTES = [
    {"text": "Будь изменением, которое хочешь видеть в мире.", "author": "Махатма Ганди", "theme": "Мотивация"},
    {"text": "Жизнь — это то, что с тобой происходит, пока ты строишь планы.", "author": "Джон Леннон", "theme": "Жизнь"},
    {"text": "Сложно победить того, кто никогда не сдаётся.", "author": "Бейб Рут", "theme": "Спорт"},
    {"text": "Успех — это способность идти от неудачи к неудаче, не теряя энтузиазма.", "author": "Уинстон Черчилль", "theme": "Мотивация"},
    {"text": "Самое важное — это не переставать задавать вопросы.", "author": "Альберт Эйнштейн", "theme": "Наука"},
    {"text": "Встань и иди, не оглядывайся.", "author": "Неизвестный", "theme": "Мотивация"},
    {"text": "Программирование — это искусство.", "author": "Дональд Кнут", "theme": "IT"},
]

def load_json(filename, default):
    if os.path.exists(filename):
        try:
            with open(filename, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return default
    return default

def save_json(filename, data):
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

# Загрузка цитат и истории
quotes = load_json(QUOTES_FILE, DEFAULT_QUOTES)
history = load_json(HISTORY_FILE, [])

def save_all():
    save_json(QUOTES_FILE, quotes)
    save_json(HISTORY_FILE, history)

# ------------------- GUI ПРИЛОЖЕНИЯ -------------------
class QuoteApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Random Quote Generator")
        self.root.geometry("800x600")
        self.root.configure(bg="#f0f4f8")

        # Переменные для фильтров
        self.filter_author = tk.StringVar(value="Все")
        self.filter_theme = tk.StringVar(value="Все")

        self.create_widgets()
        self.update_quote_display()
        self.update_history_list()
        self.update_filter_options()

    def create_widgets(self):
        # Верхняя рамка с цитатой
        quote_frame = tk.Frame(self.root, bg="#ffffff", relief="groove", bd=2)
        quote_frame.pack(pady=20, padx=20, fill="x")

        self.quote_label = tk.Label(quote_frame, text="", font=("Georgia", 14, "italic"), wraplength=700, bg="#ffffff", fg="#2c3e50")
        self.quote_label.pack(pady=30, padx=20)

        self.author_label = tk.Label(quote_frame, text="", font=("Arial", 12, "bold"), bg="#ffffff", fg="#2980b9")
        self.author_label.pack(pady=(0, 20))

        # Кнопка генерации
        self.generate_btn = tk.Button(self.root, text="✨ Сгенерировать цитату", font=("Arial", 12, "bold"),
                                      bg="#3498db", fg="white", command=self.generate_quote)
        self.generate_btn.pack(pady=10)

        # Рамка фильтров
        filter_frame = tk.Frame(self.root, bg="#e2e8f0", bd=2, relief="groove")
        filter_frame.pack(pady=10, padx=20, fill="x")

        tk.Label(filter_frame, text="Фильтр по автору:", bg="#e2e8f0", font=("Arial", 10)).grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.author_combo = ttk.Combobox(filter_frame, textvariable=self.filter_author, state="readonly", width=25)
        self.author_combo.grid(row=0, column=1, padx=5, pady=5)
        self.author_combo.bind("<<ComboboxSelected>>", lambda e: self.filter_history())

        tk.Label(filter_frame, text="Фильтр по теме:", bg="#e2e8f0", font=("Arial", 10)).grid(row=0, column=2, padx=5, pady=5, sticky="w")
        self.theme_combo = ttk.Combobox(filter_frame, textvariable=self.filter_theme, state="readonly", width=25)
        self.theme_combo.grid(row=0, column=3, padx=5, pady=5)
        self.theme_combo.bind("<<ComboboxSelected>>", lambda e: self.filter_history())

        # Кнопка сброса фильтра
        reset_btn = tk.Button(filter_frame, text="Сбросить фильтр", command=self.reset_filter, bg="#95a5a6", fg="white")
        reset_btn.grid(row=0, column=4, padx=10, pady=5)

        # История
        history_frame = tk.Frame(self.root, bg="#ffffff", bd=2, relief="groove")
        history_frame.pack(pady=10, padx=20, fill="both", expand=True)

        tk.Label(history_frame, text="📜 История сгенерированных цитат", font=("Arial", 12, "bold"), bg="#ffffff").pack(pady=5)

        scrollbar = tk.Scrollbar(history_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.history_listbox = tk.Listbox(history_frame, yscrollcommand=scrollbar.set, font=("Arial", 10), height=12)
        self.history_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=5)
        scrollbar.config(command=self.history_listbox.yview)

        # Кнопка добавления новой цитаты
        add_frame = tk.Frame(self.root, bg="#f0f4f8")
        add_frame.pack(pady=10)
        tk.Button(add_frame, text="➕ Добавить новую цитату", command=self.open_add_quote_window,
                  bg="#2ecc71", fg="white", font=("Arial", 10, "bold")).pack()

    def generate_quote(self):
        if not quotes:
            messagebox.showwarning("Нет цитат", "Список цитат пуст. Добавьте новые цитаты.")
            return
        quote = random.choice(quotes)
        self.quote_label.config(text=f"«{quote['text']}»")
        self.author_label.config(text=f"— {quote['author']} (Тема: {quote['theme']})")

        # Сохраняем в историю с временной меткой
        history.append({
            "text": quote['text'],
            "author": quote['author'],
            "theme": quote['theme'],
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })
        save_json(HISTORY_FILE, history)
        self.update_history_list()

    def update_history_list(self):
        self.history_listbox.delete(0, tk.END)
        filtered = self.get_filtered_history()
        for item in filtered:
            display = f"{item['timestamp']} | {item['author']}: {item['text'][:60]}..."
            self.history_listbox.insert(tk.END, display)

    def get_filtered_history(self):
        filtered = history
        if self.filter_author.get() != "Все":
            filtered = [q for q in filtered if q['author'] == self.filter_author.get()]
        if self.filter_theme.get() != "Все":
            filtered = [q for q in filtered if q['theme'] == self.filter_theme.get()]
        return filtered

    def filter_history(self):
        self.update_history_list()

    def reset_filter(self):
        self.filter_author.set("Все")
        self.filter_theme.set("Все")
        self.update_history_list()

    def update_filter_options(self):
        authors = sorted(set(q['author'] for q in quotes))
        themes = sorted(set(q['theme'] for q in quotes))
        self.author_combo['values'] = ["Все"] + authors
        self.theme_combo['values'] = ["Все"] + themes

    def update_quote_display(self):
        if quotes:
            quote = quotes[0]  # показываем первую для примера
            self.quote_label.config(text=f"«{quote['text']}»")
            self.author_label.config(text=f"— {quote['author']} (Тема: {quote['theme']})")

    def open_add_quote_window(self):
        add_window = tk.Toplevel(self.root)
        add_window.title("Добавить новую цитату")
        add_window.geometry("500x300")
        add_window.configure(bg="#f0f4f8")

        tk.Label(add_window, text="Текст цитаты:", bg="#f0f4f8", font=("Arial", 10)).pack(pady=(10, 0))
        text_entry = tk.Text(add_window, height=5, width=60, font=("Arial", 10))
        text_entry.pack(pady=5)

        tk.Label(add_window, text="Автор:", bg="#f0f4f8", font=("Arial", 10)).pack()
        author_entry = tk.Entry(add_window, width=40, font=("Arial", 10))
        author_entry.pack(pady=5)

        tk.Label(add_window, text="Тема:", bg="#f0f4f8", font=("Arial", 10)).pack()
        theme_entry = tk.Entry(add_window, width=40, font=("Arial", 10))
        theme_entry.pack(pady=5)

        def save_new_quote():
            text = text_entry.get("1.0", tk.END).strip()
            author = author_entry.get().strip()
            theme = theme_entry.get().strip()
            if not text or not author or not theme:
                messagebox.showwarning("Ошибка", "Все поля должны быть заполнены!")
                return
            new_quote = {"text": text, "author": author, "theme": theme}
            quotes.append(new_quote)
            save_json(QUOTES_FILE, quotes)
            self.update_filter_options()
            messagebox.showinfo("Успех", "Цитата добавлена!")
            add_window.destroy()

        tk.Button(add_window, text="Сохранить", command=save_new_quote, bg="#2ecc71", fg="white", font=("Arial", 10, "bold")).pack(pady=10)

# ------------------- ЗАПУСК -------------------
if __name__ == "__main__":
    root = tk.Tk()
    app = QuoteApp(root)
    root.mainloop()